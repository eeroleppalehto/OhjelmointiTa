import sys
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUi


class SaveDBSettingsDialog(QDialog):
    """Creates a dialog to save database settings"""

    # Constructor
    def __init__(self):
        super().__init__()

        loadUi("saveDBSettingsDialog.ui", self)

        self.setWindowTitle('Tietokantapalvelimen asetukset')

        # Elements
        self.hostLE = self.hostLineEdit
        self.portSB = self.portSpinBox
        self.cancelPB = self.cancelPushButton
        self.savePB = self.savePushButton
        self.databaseLE = self.databaseLineEdit
        self.userLE = self.userLineEdit
        self.passwordLE = self.passwordLineEdit
    

        # Set values of elements according to the current settings
        # Create an object to use setting methods

        # self.databaseOperation = pgModule.DatabaseOperation() # Needed in slots -> self # FIXME: Uncomment + add pgModule
        # currentSettings = self.databaseOperation.readDbSettingsFromJsonFile(
        #     'connectionSettings.dat')  # Read current settings, needed only in the constructor
        # self.hostLE.setText(currentSettings['server'])  # Server's host name
        # # Port number, spin box uses integer values
        # self.portSB.setValue(int(currentSettings['port']))

        # Signals
        self.cancelPB.clicked.connect(self.closeDialog)
        self.savePB.clicked.connect(self.saveSettings)

    # Slots

    # Peru button closes the dialog
    def closeDialog(self):
        self.close()

    # Tallenna button saves modified settings to a file and closes the dialog
    def saveSettings(self):
        server = self.hostLE.text()
        # Port is string in the settings file, integer in the spin box
        port = str(self.portSB.value())

        # Build new connection arguments
        newSettings = self.databaseOperation.createConnectionArgs(
            'psycotesti', 'sovellus', 'Q2werty', server, port)
        
        # Save arguments to a json file
        self.databaseOperation.saveDbSettingsToJsonFile(
            'connectionSettings.dat', newSettings)
        self.close()

class AddMemberDialog(QDialog):
    """Creates a dialog to add member to database"""
    
    # Constructor
    def __init__(self):

        super().__init__()

        loadUi("addMemberDialog.ui", self)

        self.setWindowTitle('Lisää jäsen')

        # Elements
        self.addMemberFirstNameLE = self.addMemberFirstNameLineEdit
        self.addMemberLastNameLE = self.addMemberLastNameLineEdit
        self.addMemberPostalAddressLE = self.addMemberPostalAddressLineEdit
        self.addMemberZIPLE = self.addMemberZIPLineEdit
        self.addMemberCityLE = self.addMemberCityLineEdit
        self.addMemberAddPushBtn = self.addMemberAddPushButton
        self.addMemberAddPushBtn.clicked.connect(self.addMember) # Signal
        self.addMemberCancelPushBtn = self.addMemberCancelPushButton
        self.addMemberAddPushBtn.clicked.connect(self.closeDialog) # Signal
    
    
    def addMember(self):
        # TODO: dbConnection...insertRow...try/catch...
        pass

    def closeDialog(self):
        self.close()

class RemoveMemberDialog(QDialog):
    """Creates a dialog to remove member from database"""
    
    # Constructor
    def __init__(self):

        super().__init__()

        loadUi("removeMemberDialog.ui", self)

        self.setWindowTitle('Poista jäsen')

        # Elements
        self.removeMemberCB = self.removeMemberComboBox
        
        
        self.removeMemberPushBtn = self.removeMemberPushButton
        self.removeMemberPushBtn.clicked.connect(self.removeMember) # Signal
        self.removeMemberCancelPushBtn = self.removeMemberCancelPushButton
        self.removeMemberCancelPushBtn.clicked.connect(self.closeDialog) # Signal
    
    
    def removeMember(self):
        # TODO: dbConnection...deleteRow...try/catch...
        pass

    def closeDialog(self):
        self.close()

class AddMembershipDialog(QDialog):
    """Creates a dialog to add membership to database"""
    
    # Constructor
    def __init__(self):

        # TODO: set current day as default
        super().__init__()

        loadUi("addMembershipDialog.ui", self)

        self.setWindowTitle('Lisää jäsen ryhmään')

        # Elements
        self.membershipMemberCB = self.membershipMemberComboBox
        self.membershipGroupCB = self.membershipGroupComboBox
        self.membershipShareCB = self.membershipShareComboBox
        self.membershipJoinDE = self.membershipJoinDateEdit

        self.membershipAddPushBtn = self.membershipAddPushButton
        self.membershipAddPushBtn.clicked.connect(self.addMembership) # Signal
        self.membershipCancelPushBtn = self.membershipCancelPushButton
        self.membershipCancelPushBtn.clicked.connect(self.closeDialog) # Signal
    
    
    def addMembership(self):
        # TODO: dbConnection...insertRow...try/catch...
        pass

    def closeDialog(self):
        self.close()

class AddGroupDialog(QDialog):
    """Creates a dialog to add group to database"""
    
    # Constructor
    def __init__(self):

        super().__init__()

        loadUi("addGroupDialog.ui", self)

        self.setWindowTitle('Lisää ryhmä')

        # Elements
        self.addGroupGroupNameLE = self.addGroupGroupNameLineEdit
        self.addGroupPartyCB = self.addGroupPartyComboBox
        
        self.addGroupAddPushBtn = self.addGroupAddPushButton
        self.addGroupAddPushBtn.clicked.connect(self.addGroup) # Signal
        self.addGroupCancelPushBtn = self.addGroupCancelPushButton
        self.addGroupCancelPushBtn.clicked.connect(self.closeDialog) # Signal
    
    
    def addGroup(self):
        # TODO: dbConnection...insertRow...try/catch...
        pass

    def closeDialog(self):
        self.close()

class RemoveGroupDialog(QDialog):
    """Creates a dialog to remove group from database"""
    
    # Constructor
    def __init__(self):

        super().__init__()

        loadUi("removeGroupDialog.ui", self)

        self.setWindowTitle('Poista ryhmä')

        # Elements
        self.removeGroupCB = self.removeGroupComboBox
        
        
        self.removeGroupRemovePushBtn = self.removeGroupRemovePushButton
        self.removeGroupRemovePushBtn.clicked.connect(self.removeGroup) # Signal
        self.removeGroupCancelPushBtn = self.removeGroupCancelPushButton
        self.removeGroupCancelPushBtn.clicked.connect(self.closeDialog) # Signal
    
    
    def removeGroup(self):
        # TODO: dbConnection...deleteRow...try/catch...
        pass

    def closeDialog(self):
        self.close()

class AddPartyDialog(QDialog):
    """Creates a dialog to add party to database"""
    
    # Constructor
    def __init__(self):

        super().__init__()

        loadUi("addPartyDialog.ui", self)

        self.setWindowTitle('Lisää seurue')

        # Elements
        self.addPartyNameLE = self.addPartyNameLineEdit
        self.addPartyLeaderCB = self.addPartyLeaderComboBox
        
        self.addPartyAddPushBtn = self.addPartyAddPushButton
        self.addPartyAddPushBtn.clicked.connect(self.addParty) # Signal
        self.addPartyCancelPushBtn = self.addPartyCancelPushButton
        self.addPartyCancelPushBtn.clicked.connect(self.closeDialog) # Signal
    
    
    def addParty(self):
        # TODO: dbConnection...insertRow...try/catch...
        pass

    def closeDialog(self):
        self.close()

class RemoveGroupDialog(QDialog):
    """Creates a dialog to remove party from database"""
    
    # Constructor
    def __init__(self):

        super().__init__()

        loadUi("removePartyDialog.ui", self)

        self.setWindowTitle('Poista seurue')

        # Elements
        self.removePartyCB = self.removePartyComboBox
        
        
        self.removePartyRemovePushBtn = self.removePartyRemovePushButton
        self.removePartyRemovePushBtn.clicked.connect(self.removeParty) # Signal
        self.removePartyCancelPushBtn = self.removePartyCancelPushButton
        self.removePartyCancelPushBtn.clicked.connect(self.closeDialog) # Signal
    
    
    def removeParty(self):
        # TODO: dbConnection...deleteRow...try/catch...
        pass

    def closeDialog(self):
        self.close()

class EditCompanyDialog(QDialog):
    """Creates a dialog to edit company in database"""
    
    # Constructor
    def __init__(self):

        super().__init__()

        loadUi("editCompanyDialog.ui", self)

        self.setWindowTitle('Muokkaa seuraa')

        # Elements
        self.editCompanyNameLE = self.editCompanyNameLineEdit
        self.editCompanyPostalAddressLE = self.editCompanyPostalAddressLineEdit
        self.editCompanyZIPLE = self.editCompanyZIPLineEdit
        self.editCompanyCityLE = self.editCompanyCityLineEdit

        self.editCompanySavePushBtn = self.editCompanySavePushButton
        self.editCompanySavePushBtn.clicked.connect(self.editCompany) # Signal
        self.editCompanyCancelPushBtn = self.editCompanyCancelPushButton
        self.editCompanyCancelPushBtn.clicked.connect(self.closeDialog) # Signal
    
    
    def editCompany(self):
        # TODO: dbConnection...insertRow...try/catch...
        pass

    def closeDialog(self):
        self.close()

class TestMainWindow(QMainWindow):
    """Main Window for testing dialogs."""

    def __init__(self):
        super().__init__()

        self.setWindowTitle('Pääikkuna dialogien testaukseen')

        # Add dialogs to be tested here and run them as follows:
        saveDBSettingsDialog = SaveDBSettingsDialog()
        saveDBSettingsDialog.exec()

# Some tests
if __name__ == "__main__":

    # Create a testing application
    testApp = QApplication(sys.argv)

    # Create a main window for testing a dialog
    testMainWindow = TestMainWindow()
    testMainWindow.show()

    # Run the testing application
    testApp.exec()